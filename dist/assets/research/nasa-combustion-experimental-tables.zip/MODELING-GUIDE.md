# NASA experimental tables and modeling support

This package contains the complete official experimental CSV tables available in nine inspected PSI investigations. It preserves **671 source rows and 8,546 original cells**. These are not 671 independent experiments: source notes, configuration ranges, repeated/aged measurements and maintenance records remain identifiable. No prediction model was trained by this export.

| Investigation | PSI | Source rows | What a row represents |
|---|---|---:|---|
| BASS-II | 25 | 129 | Test table record |
| BASS | 26 | 122 | 121 as-run records and one soot-cleaning entry |
| SAME-R | 101 | 109 | Test conditions and aged/repeated measurement records |
| SAME | 102 | 8 | Sample/condition templates, including references to conditions 1–4 |
| FLEX | 69 | 274 | Individual droplet tests with reported termination categories |
| FLEX-2 | 68 | 8 | Fuel/configuration envelopes containing ranges and alternatives |
| Saffire-I | 98 | 4 | Two sample summaries and two pre-test flow-video references |
| Saffire-II | 99 | 15 | Nine sample summaries, two flow-video references and four notes |
| Saffire-III | 100 | 2 | Two sample summaries |

## Files and provenance

`source-csv/` contains original downloaded bytes. Do not substitute the normalized files when citing the original CSV. Each dataset's source object includes the exact NASA download URL, catalog URL, encoding, byte count and SHA256. Downloads were checked against PSI-index byte counts. FLEX CSV decodes as Windows-1252; the other files decode as UTF-8. No original file was modified.

`experimental-tables.json` contains all records and a per-dataset dictionary. `data-dictionary.json` provides the dictionary without record data. Each field has a canonical key, original header, source column, source unit, semantic role, missing count and qualifier counts. Each record has a globally unique `PSI-n:row:r` ID and original CSV row number. Its `raw` array preserves all source cell strings in original column order. `values` contains conservatively parsed scalars or original non-scalar text. `qualifiers` distinguish numeric, explicit-unit, approximate, missing, range, option and ambiguous values.

`normalized-csv/` contains a flat export for every investigation. Each canonical field is accompanied by a `__qualifier` column. Missing values are empty in CSV and null in JSON; the raw source and qualifiers distinguish an empty cell from a written missing token. `cell-quality.csv` lists cells needing attention. Header spaces, misspellings, source dates and raw missing markers remain intact in the original files and JSON raw cells. No ranges were expanded into fabricated tests, no forward-fill or imputation was performed, and units were not converted.

`export-audit.json` records row, cell and outcome counts. `package-manifest.json` records checksums of packaged files. The ZIP contains only reusable data, dictionaries, audit and this guide; API snapshots/build scripts remain outside it.

## FLEX: a bounded modeling example

The 274 FLEX rows contain 157 Methanol and 117 Heptane records. Original termination labels are **Extinction (186), Disruption (61), Completion (27)**. Retain these exact categories. Disruption is a separate physical/test outcome, not evidence of successful fire suppression. The label distribution is not a suppressant efficacy score because fuel, pressure, composition and diameter differ across tests.

`flex-initial-conditions-and-outcomes.csv` selects fuel, ambient pressure in mmHg, the four original gas-fraction columns, initial droplet diameter in mm, and the original end label. It deliberately excludes burn time, burning rate and extinction diameter from predictors: those describe the outcome and would leak information when predicting how a test ends.

The CSV headers literally name gas species `O`, `N`, `CO`, `He`. **NASA/TP-2015-216046 Table IX (printed page 20) confirms O₂, N₂, CO₂ and He**, and confirms the burning-rate unit as **mm²/s**. The original table was visually inspected and its first two identifiers (20CAL08 and 20CAL10) and values were checked against the CSV. Raw CSV headers remain unchanged. Stable canonical keys remain `oHeaderMoleFraction`, `nHeaderMoleFraction`, and `coHeaderMoleFraction`; field metadata now explicitly identifies the verified species. The modeling CSV review flag is 0 after corroboration. The `CO` source column is carbon dioxide, not carbon monoxide.

The burning-rate field retains key `burningRateSourceUnit`, raw header and raw source-unit `mm`, while its interpreted `unit` is `mm²/s`. No numeric conversion was performed. The report defines this as an average burning-rate constant from a linear fit of droplet diameter squared versus time shortly after ignition to extinction (printed page 19). It defines initial diameter at time zero when igniters turn on, so initial diameter is not a long-horizon pre-ignition measurement. [Primary NASA report](https://ntrs.nasa.gov/api/citations/20150023456/downloads/20150023456.pdf).

The complete downloaded PSI CSV remains 274 records. Do not equate its row count or numeric test sequence with the complete report series. Join to the report using FLEX Identifier plus verified conditions, not an unverified numerical test-number match.

Initial diameter is missing in 12 records, extinction diameter in 77, and burn time in six. Some burn-time values are approximate (`~6`, `~9`). Gas fractions sometimes sum to 0.98, 0.99 or 1.01; reported fractions are retained and flagged, not renormalized. Report excluded/missing cases for each analysis. Do not infer zero extinction diameter from a blank or dash.

For a future reproducible baseline, declare the target and exclusion policy, using the corroborated species and units. Split related condition groups or experimental campaigns between training and evaluation to reduce leakage from repeated settings. Fit preprocessing on training data only. Report class-wise results, class imbalance, missingness and uncertainty on a held-out set. Compare against a simple baseline. These steps support a droplet-test model within the observed domain; they do not validate pre-ignition spacecraft fire forecasting, cabin spread, arbitrary solid materials, or lunar/Martian gravity prediction.

## Cross-investigation interpretation

- BASS/BASS-II fan and air display strings do not establish calibrated speed, fan power or timed commands. Preserve sequences and notes as text. Endpoint gas measurements are distinct from initial conditions and can leak outcome information.
- BASS as-run/sample IDs recur. SAME-R has aged rows and a duplicate textual test ID. Grouping and joins must use record provenance, not assume unique numeric test IDs or independent rows.
- FLEX-2 ranges/options and SAME templates describe experimental configuration scope. They are not measured combinations and cannot become synthetic training examples by taking a Cartesian product.
- Saffire-II oxygen values are derived from measured CO2 and referenced to initial ISS O2 according to source Note 1; they are not interchangeable with an independent O2 sensor trace. Blank material cells for samples 2-6 and 2-9 remain blank. `037 mm`, `?-g` headers and spread-length/rate mismatches are flagged, not repaired.
- Saffire-I/II burn-time summaries, ignition durations and flow references must not overwrite the actual recorded telemetry time axis. Per-table conditions are not validated continuous control commands.
- Comparisons across campaigns require matching material, geometry, atmosphere, pressure, flow, measurement definitions and gravity context. This package supplies no common safety score and no validated gravity-transfer formula.

Every dataset links directly to its primary NASA source; interpretation should be checked against the associated science documentation before fitting a scientific model.
